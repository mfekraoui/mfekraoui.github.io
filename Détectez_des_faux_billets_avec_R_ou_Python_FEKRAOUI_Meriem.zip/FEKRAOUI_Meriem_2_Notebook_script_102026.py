import sys
import pandas as pd
import joblib

# Vérifier que le fichier CSV est fourni
if len(sys.argv) != 2:
    print("Utilisation : python prediction.py fichier.csv")
    sys.exit(1)

fichier_csv = sys.argv[1]

# Charger le modèle sauvegardé
model = joblib.load("modele_billets.pkl")

# Charger le fichier de production
df = pd.read_csv(fichier_csv, sep=",")

# Sélectionner les variables nécessaires
features = [
    "diagonal",
    "height_left",
    "height_right",
    "margin_low",
    "margin_up",
    "length"
]

X = df[features]

# Effectuer les prédictions
predictions = model.predict(X)

# Afficher les résultats
for i, prediction in enumerate(predictions, 1):
    if prediction:
        print(f"Billet {i} : Authentique")
    else:
        print(f"Billet {i} : Contrefait")